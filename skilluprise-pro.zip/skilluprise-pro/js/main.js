// Main JavaScript File - Common Functions

// Execute when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeTheme();
    initializeMobileMenu();
    initializeForms();
    initializeToastNotifications();
    loadUserData();
});

// Theme Initialization
function initializeTheme() {
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
        
        // Check saved theme preference
        const savedTheme = localStorage.getItem('theme') || 'light';
        setTheme(savedTheme);
    }
}

// Toggle Theme
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
}

// Set Theme
function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.textContent = theme === 'light' ? '🌙' : '☀️';
    }
}

// Mobile Menu Initialization
function initializeMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            mobileMenuBtn.classList.toggle('active');
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!navLinks.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                navLinks.classList.remove('active');
                mobileMenuBtn.classList.remove('active');
            }
        });
    }
}

// Form Initialization
function initializeForms() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', handleFormSubmit);
        
        // Add validation for required fields
        const requiredFields = form.querySelectorAll('[required]');
        requiredFields.forEach(field => {
            field.addEventListener('blur', validateField);
        });
    });
}

// Form Submit Handler
async function handleFormSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const formId = form.id || form.className;
    
    // Show loading state
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Processing...';
    submitBtn.disabled = true;
    
    try {
        // Simulate API call
        await simulateApiCall(formId, formData);
        
        showToast('Submitted successfully!', 'success');
        form.reset();
    } catch (error) {
        showToast(`Submission failed: ${error.message}`, 'error');
    } finally {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

// Field Validation
function validateField(e) {
    const field = e.target;
    const value = field.value.trim();
    const errorElement = field.parentElement.querySelector('.error-message') || 
                         createErrorElement(field);
    
    // Clear previous error
    errorElement.textContent = '';
    field.classList.remove('error');
    
    if (field.required && !value) {
        showFieldError(field, errorElement, 'This field is required');
        return false;
    }
    
    // Email validation
    if (field.type === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            showFieldError(field, errorElement, 'Please enter a valid email address');
            return false;
        }
    }
    
    // Password strength validation
    if (field.type === 'password' && value) {
        if (value.length < 8) {
            showFieldError(field, errorElement, 'Password must be at least 8 characters');
            return false;
        }
    }
    
    return true;
}

function showFieldError(field, errorElement, message) {
    errorElement.textContent = message;
    field.classList.add('error');
}

function createErrorElement(field) {
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.style.color = 'var(--error-color)';
    errorElement.style.fontSize = '0.875rem';
    errorElement.style.marginTop = '0.25rem';
    field.parentElement.appendChild(errorElement);
    return errorElement;
}

// Simulate API Call
function simulateApiCall(endpoint, data) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // Simulate 90% success rate
            if (Math.random() < 0.9) {
                console.log(`API call successful: ${endpoint}`, data);
                resolve({ success: true });
            } else {
                reject(new Error('Network request failed, please try again'));
            }
        }, 1000);
    });
}

// Toast Notification System
function initializeToastNotifications() {
    // Create notification container
    const toastContainer = document.createElement('div');
    toastContainer.id = 'toast-container';
    toastContainer.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        max-width: 350px;
    `;
    document.body.appendChild(toastContainer);
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const colors = {
        success: 'var(--success-color)',
        error: 'var(--error-color)',
        info: 'var(--primary-color)',
        warning: 'var(--accent-color)'
    };
    
    toast.style.cssText = `
        background: white;
        color: var(--text-dark);
        padding: 1rem;
        margin-bottom: 0.5rem;
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-lg);
        border-left: 4px solid ${colors[type]};
        animation: slideIn 0.3s ease;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    `;
    
    toast.innerHTML = `
        <span style="color: ${colors[type]}; font-size: 1.25rem;">${getToastIcon(type)}</span>
        <span>${message}</span>
    `;
    
    const container = document.getElementById('toast-container');
    container.appendChild(toast);
    
    // Auto-remove notification
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
    
    // Add CSS animations
    if (!document.getElementById('toast-animations')) {
        const style = document.createElement('style');
        style.id = 'toast-animations';
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
}

function getToastIcon(type) {
    const icons = {
        success: '✓',
        error: '✗',
        info: 'ℹ',
        warning: '⚠'
    };
    return icons[type] || 'ℹ';
}

// User Data Management
function loadUserData() {
    const user = getUserData();
    updateUIForUser(user);
}

function getUserData() {
    const saved = localStorage.getItem('skilluprise_user');
    return saved ? JSON.parse(saved) : null;
}

function saveUserData(userData) {
    localStorage.setItem('skilluprise_user', JSON.stringify(userData));
    updateUIForUser(userData);
}

function updateUIForUser(user) {
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const userMenu = document.getElementById('userMenu');
    
    if (user) {
        if (loginBtn) loginBtn.style.display = 'none';
        if (registerBtn) registerBtn.style.display = 'none';
        if (userMenu) {
            userMenu.style.display = 'flex';
            userMenu.innerHTML = `
                <span>Welcome, ${user.name}</span>
                <button onclick="logout()" class="btn btn-outline">Logout</button>
            `;
        }
    }
}

function logout() {
    localStorage.removeItem('skilluprise_user');
    location.reload();
}

// Utility Functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    }).format(new Date(date));
}

// Export to global scope
window.skilluprise = {
    showToast,
    formatCurrency,
    formatDate,
    getUserData,
    saveUserData,
    logout
};
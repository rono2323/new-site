// Payment Processing Functions

class PaymentManager {
    constructor() {
        this.selectedMethod = null;
        this.testId = null;
        this.testDetails = null;
        this.initializePaymentPage();
    }
    
    initializePaymentPage() {
        // Get test ID
        const urlParams = new URLSearchParams(window.location.search);
        this.testId = urlParams.get('test');
        
        if (!this.testId) {
            window.location.href = 'tests.html';
            return;
        }
        
        // Load test details
        this.loadTestDetails();
        
        // Initialize payment method selection
        this.initializePaymentMethods();
        
        // Initialize form validation
        this.initializeFormValidation();
        
        // Setup back button
        const backBtn = document.getElementById('backToTest');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                window.history.back();
            });
        }
    }
    
    loadTestDetails() {
        // Simulate API call to get test details
        this.testDetails = {
            id: this.testId,
            title: 'Web Development Basics Test',
            price: 199,
            description: 'Test your web development fundamental knowledge',
            duration: '60 minutes'
        };
        
        // Update page
        const testTitle = document.getElementById('testTitle');
        const testPrice = document.getElementById('testPrice');
        
        if (testTitle) {
            testTitle.textContent = this.testDetails.title;
        }
        
        if (testPrice) {
            testPrice.textContent = `$${this.testDetails.price}`;
        }
        
        // Update total price
        this.updateTotalPrice();
    }
    
    initializePaymentMethods() {
        const methods = document.querySelectorAll('.payment-method');
        methods.forEach(method => {
            method.addEventListener('click', () => {
                this.selectPaymentMethod(method);
            });
        });
        
        // Select first method by default
        if (methods.length > 0) {
            this.selectPaymentMethod(methods[0]);
        }
    }
    
    selectPaymentMethod(methodElement) {
        // Remove selected class from all methods
        document.querySelectorAll('.payment-method').forEach(m => {
            m.classList.remove('selected');
        });
        
        // Add selected class to clicked method
        methodElement.classList.add('selected');
        this.selectedMethod = methodElement.dataset.method;
        
        // Show/hide form sections based on selection
        this.toggleFormSections();
    }
    
    toggleFormSections() {
        const cardForm = document.getElementById('cardForm');
        const paypalForm = document.getElementById('paypalForm');
        const bankForm = document.getElementById('bankForm');
        
        // Hide all forms
        if (cardForm) cardForm.style.display = 'none';
        if (paypalForm) paypalForm.style.display = 'none';
        if (bankForm) bankForm.style.display = 'none';
        
        // Show selected form
        switch(this.selectedMethod) {
            case 'card':
                if (cardForm) cardForm.style.display = 'block';
                break;
            case 'paypal':
                if (paypalForm) paypalForm.style.display = 'block';
                break;
            case 'bank':
                if (bankForm) bankForm.style.display = 'block';
                break;
        }
    }
    
    initializeFormValidation() {
        const form = document.getElementById('paymentForm');
        if (!form) return;
        
        // Card number validation
        const cardNumber = document.getElementById('cardNumber');
        if (cardNumber) {
            cardNumber.addEventListener('input', (e) => {
                this.formatCardNumber(e.target);
            });
        }
        
        // Expiry date validation
        const expiryDate = document.getElementById('expiryDate');
        if (expiryDate) {
            expiryDate.addEventListener('input', (e) => {
                this.formatExpiryDate(e.target);
            });
        }
        
        // CVV validation
        const cvv = document.getElementById('cvv');
        if (cvv) {
            cvv.addEventListener('input', (e) => {
                this.validateCVV(e.target);
            });
        }
        
        // Form submission
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.processPayment();
        });
    }
    
    formatCardNumber(input) {
        let value = input.value.replace(/\D/g, '');
        value = value.substring(0, 16);
        
        // Add spaces every 4 digits
        value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
        input.value = value;
        
        // Detect card type
        this.detectCardType(value.replace(/\s/g, ''));
    }
    
    detectCardType(cardNumber) {
        const cardTypeElement = document.getElementById('cardType');
        if (!cardTypeElement) return;
        
        let cardType = 'Unknown';
        
        // Visa
        if (/^4/.test(cardNumber)) {
            cardType = 'Visa';
        }
        // Mastercard
        else if (/^5[1-5]/.test(cardNumber)) {
            cardType = 'Mastercard';
        }
        // American Express
        else if (/^3[47]/.test(cardNumber)) {
            cardType = 'American Express';
        }
        // Discover
        else if (/^6(?:011|5)/.test(cardNumber)) {
            cardType = 'Discover';
        }
        
        cardTypeElement.textContent = cardType;
    }
    
    formatExpiryDate(input) {
        let value = input.value.replace(/\D/g, '');
        
        if (value.length >= 2) {
            let month = value.substring(0, 2);
            let year = value.substring(2, 4);
            
            // Validate month
            month = Math.min(parseInt(month), 12).toString().padStart(2, '0');
            
            if (year) {
                input.value = `${month}/${year}`;
            } else {
                input.value = month;
            }
        }
    }
    
    validateCVV(input) {
        let value = input.value.replace(/\D/g, '');
        value = value.substring(0, 4);
        input.value = value;
    }
    
    validateForm() {
        let isValid = true;
        const errors = [];
        
        switch(this.selectedMethod) {
            case 'card':
                // Validate card number
                const cardNumber = document.getElementById('cardNumber').value.replace(/\s/g, '');
                if (cardNumber.length !== 16) {
                    errors.push('Card number must be 16 digits');
                    isValid = false;
                }
                
                // Validate expiry date
                const expiryDate = document.getElementById('expiryDate').value;
                if (!this.validateExpiryDate(expiryDate)) {
                    errors.push('Invalid expiry date');
                    isValid = false;
                }
                
                // Validate CVV
                const cvv = document.getElementById('cvv').value;
                if (cvv.length < 3 || cvv.length > 4) {
                    errors.push('CVV must be 3-4 digits');
                    isValid = false;
                }
                break;
                
            case 'paypal':
                // Validate PayPal email
                const paypalEmail = document.getElementById('paypalEmail').value;
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(paypalEmail)) {
                    errors.push('Invalid PayPal email address');
                    isValid = false;
                }
                break;
                
            case 'bank':
                // Validate bank details
                const accountName = document.getElementById('accountName').value;
                const accountNumber = document.getElementById('accountNumber').value;
                const routingNumber = document.getElementById('routingNumber').value;
                
                if (!accountName.trim()) {
                    errors.push('Account name is required');
                    isValid = false;
                }
                
                if (!accountNumber.trim() || !/^\d+$/.test(accountNumber)) {
                    errors.push('Invalid account number');
                    isValid = false;
                }
                
                if (!routingNumber.trim() || !/^\d{9}$/.test(routingNumber)) {
                    errors.push('Routing number must be 9 digits');
                    isValid = false;
                }
                break;
        }
        
        return { isValid, errors };
    }
    
    validateExpiryDate(dateString) {
        if (!dateString || !dateString.includes('/')) return false;
        
        const [month, year] = dateString.split('/').map(num => parseInt(num, 10));
        if (isNaN(month) || isNaN(year) || month < 1 || month > 12) return false;
        
        const currentDate = new Date();
        const currentYear = currentDate.getFullYear() % 100;
        const currentMonth = currentDate.getMonth() + 1;
        
        if (year < currentYear || (year === currentYear && month < currentMonth)) {
            return false;
        }
        
        return true;
    }
    
    async processPayment() {
        const validation = this.validateForm();
        
        if (!validation.isValid) {
            validation.errors.forEach(error => {
                skilluprise.showToast(error, 'error');
            });
            return;
        }
        
        // Show processing state
        const submitBtn = document.querySelector('#paymentForm button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Processing...';
        submitBtn.disabled = true;
        
        try {
            // Simulate payment processing
            const result = await this.simulatePayment();
            
            if (result.success) {
                // Save purchase record
                this.savePurchaseRecord();
                
                // Show success message
                skilluprise.showToast('Payment successful!', 'success');
                
                // Redirect to test page
                setTimeout(() => {
                    window.location.href = `begin-test.html?id=${this.testId}`;
                }, 2000);
            } else {
                throw new Error(result.message || 'Payment failed');
            }
        } catch (error) {
            skilluprise.showToast(`Payment failed: ${error.message}`, 'error');
        } finally {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    }
    
    simulatePayment() {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Simulate 85% success rate
                if (Math.random() < 0.85) {
                    resolve({
                        success: true,
                        transactionId: 'TXN' + Date.now(),
                        amount: this.testDetails.price,
                        method: this.selectedMethod,
                        timestamp: new Date().toISOString()
                    });
                } else {
                    reject(new Error('Payment processing failed. Please try again.'));
                }
            }, 2000);
        });
    }
    
    savePurchaseRecord() {
        const purchase = {
            testId: this.testId,
            testTitle: this.testDetails.title,
            amount: this.testDetails.price,
            method: this.selectedMethod,
            date: new Date().toISOString(),
            status: 'completed'
        };
        
        // Save to purchase history
        const purchases = JSON.parse(localStorage.getItem('purchase_history') || '[]');
        purchases.push(purchase);
        localStorage.setItem('purchase_history', JSON.stringify(purchases));
        
        // Mark test as purchased
        const purchasedTests = JSON.parse(localStorage.getItem('purchased_tests') || '[]');
        if (!purchasedTests.includes(this.testId)) {
            purchasedTests.push(this.testId);
            localStorage.setItem('purchased_tests', JSON.stringify(purchasedTests));
        }
    }
    
    updateTotalPrice() {
        const subtotal = this.testDetails.price;
        const tax = subtotal * 0.1; // 10% tax
        const total = subtotal + tax;
        
        const subtotalElement = document.getElementById('subtotal');
        const taxElement = document.getElementById('tax');
        const totalElement = document.getElementById('total');
        
        if (subtotalElement) subtotalElement.textContent = `$${subtotal.toFixed(2)}`;
        if (taxElement) taxElement.textContent = `$${tax.toFixed(2)}`;
        if (totalElement) totalElement.textContent = `$${total.toFixed(2)}`;
    }
}

// Initialize PaymentManager when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.paymentManager = new PaymentManager();
});
// Test Related Functions

class TestManager {
    constructor() {
        this.currentTest = null;
        this.currentQuestionIndex = 0;
        this.userAnswers = {};
        this.timer = null;
        this.timeRemaining = 0;
        
        this.initializeTestPage();
    }
    
    initializeTestPage() {
        // Check current page
        const path = window.location.pathname;
        
        if (path.includes('test-detail.html')) {
            this.initializeTestDetail();
        } else if (path.includes('begin-test.html')) {
            this.initializeTestTaking();
        } else if (path.includes('tests.html')) {
            this.initializeTestList();
        }
    }
    
    initializeTestList() {
        this.loadTests();
        this.setupSearch();
        this.setupFilters();
    }
    
    loadTests() {
        const tests = this.getMockTests();
        const container = document.getElementById('testsContainer');
        
        if (!container) return;
        
        container.innerHTML = tests.map(test => this.createTestCard(test)).join('');
        
        // Add click events
        document.querySelectorAll('.test-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.closest('.btn')) {
                    const testId = card.dataset.testId;
                    window.location.href = `test-detail.html?id=${testId}`;
                }
            });
        });
    }
    
    createTestCard(test) {
        return `
            <div class="test-card" data-test-id="${test.id}">
                <img src="${test.image}" alt="${test.title}">
                <div class="test-card-content">
                    <h3>${test.title}</h3>
                    <p class="test-description">${test.description}</p>
                    <div class="test-tags">
                        ${test.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                    </div>
                    <div class="test-meta">
                        <span>⏱️ ${test.duration} min</span>
                        <span>📝 ${test.questions} questions</span>
                        <span>🎯 ${test.difficulty}</span>
                    </div>
                    <div class="test-price">${test.price}</div>
                    <button class="btn btn-primary" onclick="testManager.startTest('${test.id}')">
                        Start Test
                    </button>
                </div>
            </div>
        `;
    }
    
    initializeTestDetail() {
        const testId = new URLSearchParams(window.location.search).get('id');
        this.loadTestDetails(testId);
        this.setupTestActions();
    }
    
    loadTestDetails(testId) {
        const test = this.getMockTestDetails(testId);
        if (!test) {
            window.location.href = 'tests.html';
            return;
        }
        
        // Update page content
        document.title = `${test.title} - SkillUprise Pro`;
        
        const elements = {
            testTitle: document.getElementById('testTitle'),
            testDescription: document.getElementById('testDescription'),
            testPrice: document.getElementById('testPrice'),
            testDuration: document.getElementById('testDuration'),
            testQuestions: document.getElementById('testQuestions'),
            testLevel: document.getElementById('testLevel'),
            testSyllabus: document.getElementById('testSyllabus')
        };
        
        // Populate data
        if (elements.testTitle) elements.testTitle.textContent = test.title;
        if (elements.testDescription) elements.testDescription.textContent = test.description;
        if (elements.testPrice) elements.testPrice.textContent = test.price;
        if (elements.testDuration) elements.testDuration.textContent = `${test.duration} min`;
        if (elements.testQuestions) elements.testQuestions.textContent = `${test.questions} questions`;
        if (elements.testLevel) elements.testLevel.textContent = test.difficulty;
        
        // Populate syllabus
        if (elements.testSyllabus) {
            elements.testSyllabus.innerHTML = test.syllabus
                .map(item => `<li>${item}</li>`)
                .join('');
        }
    }
    
    initializeTestTaking() {
        const testId = new URLSearchParams(window.location.search).get('id');
        this.currentTest = this.getMockTestDetails(testId);
        
        if (!this.currentTest) {
            window.location.href = 'tests.html';
            return;
        }
        
        this.initializeTest();
        this.startTimer();
        this.setupTestControls();
    }
    
    initializeTest() {
        this.currentQuestionIndex = 0;
        this.userAnswers = {};
        this.displayCurrentQuestion();
        this.updateProgress();
    }
    
    displayCurrentQuestion() {
        const question = this.currentTest.questions[this.currentQuestionIndex];
        if (!question) return;
        
        const container = document.getElementById('questionContainer');
        if (!container) return;
        
        container.innerHTML = `
            <div class="question-card">
                <div class="question-header">
                    <span class="question-number">Question ${this.currentQuestionIndex + 1}/${this.currentTest.questions.length}</span>
                </div>
                <div class="question-text">${question.text}</div>
                <ul class="options-list">
                    ${question.options.map((option, index) => `
                        <li class="option-item ${this.userAnswers[this.currentQuestionIndex] === index ? 'selected' : ''}"
                            onclick="testManager.selectAnswer(${index})">
                            <span class="option-label">${String.fromCharCode(65 + index)}</span>
                            <span class="option-text">${option}</span>
                        </li>
                    `).join('')}
                </ul>
            </div>
        `;
    }
    
    selectAnswer(optionIndex) {
        this.userAnswers[this.currentQuestionIndex] = optionIndex;
        
        // Update UI
        document.querySelectorAll('.option-item').forEach((item, index) => {
            item.classList.toggle('selected', index === optionIndex);
        });
        
        // Auto-save answer
        this.saveProgress();
    }
    
    nextQuestion() {
        if (this.currentQuestionIndex < this.currentTest.questions.length - 1) {
            this.currentQuestionIndex++;
            this.displayCurrentQuestion();
            this.updateProgress();
        }
    }
    
    previousQuestion() {
        if (this.currentQuestionIndex > 0) {
            this.currentQuestionIndex--;
            this.displayCurrentQuestion();
            this.updateProgress();
        }
    }
    
    updateProgress() {
        const progress = ((this.currentQuestionIndex + 1) / this.currentTest.questions.length) * 100;
        const progressBar = document.getElementById('progressFill');
        if (progressBar) {
            progressBar.style.width = `${progress}%`;
        }
        
        const progressText = document.getElementById('progressText');
        if (progressText) {
            progressText.textContent = `${this.currentQuestionIndex + 1}/${this.currentTest.questions.length}`;
        }
    }
    
    startTimer() {
        this.timeRemaining = this.currentTest.duration * 60; // Convert to seconds
        
        this.timer = setInterval(() => {
            this.timeRemaining--;
            this.updateTimerDisplay();
            
            if (this.timeRemaining <= 0) {
                this.submitTest();
            }
            
            // Auto-save every 30 seconds
            if (this.timeRemaining % 30 === 0) {
                this.saveProgress();
            }
        }, 1000);
    }
    
    updateTimerDisplay() {
        const minutes = Math.floor(this.timeRemaining / 60);
        const seconds = this.timeRemaining % 60;
        const timerElement = document.getElementById('testTimer');
        
        if (timerElement) {
            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            // Show warning for last 5 minutes
            if (this.timeRemaining <= 300) {
                timerElement.style.color = 'var(--error-color)';
                timerElement.classList.add('pulse');
            }
        }
    }
    
    submitTest() {
        clearInterval(this.timer);
        
        // Calculate score
        const score = this.calculateScore();
        
        // Save result
        this.saveTestResult(score);
        
        // Show result
        this.showTestResult(score);
        
        // Redirect to certificate page after 3 seconds
        setTimeout(() => {
            window.location.href = `certificate.html?test=${this.currentTest.id}&score=${score}`;
        }, 3000);
    }
    
    calculateScore() {
        let correct = 0;
        this.currentTest.questions.forEach((question, index) => {
            if (this.userAnswers[index] === question.correctAnswer) {
                correct++;
            }
        });
        
        return Math.round((correct / this.currentTest.questions.length) * 100);
    }
    
    saveProgress() {
        const progress = {
            testId: this.currentTest.id,
            questionIndex: this.currentQuestionIndex,
            answers: this.userAnswers,
            timeRemaining: this.timeRemaining,
            timestamp: new Date().toISOString()
        };
        
        localStorage.setItem(`test_progress_${this.currentTest.id}`, JSON.stringify(progress));
    }
    
    loadProgress() {
        const saved = localStorage.getItem(`test_progress_${this.currentTest.id}`);
        if (saved) {
            const progress = JSON.parse(saved);
            this.currentQuestionIndex = progress.questionIndex || 0;
            this.userAnswers = progress.answers || {};
            this.timeRemaining = progress.timeRemaining || this.currentTest.duration * 60;
            
            // Check if expired (24 hours)
            const savedTime = new Date(progress.timestamp);
            const now = new Date();
            const hoursDiff = (now - savedTime) / (1000 * 60 * 60);
            
            if (hoursDiff > 24) {
                this.clearProgress();
                return;
            }
            
            this.displayCurrentQuestion();
            this.updateProgress();
            this.updateTimerDisplay();
        }
    }
    
    clearProgress() {
        localStorage.removeItem(`test_progress_${this.currentTest.id}`);
    }
    
    saveTestResult(score) {
        const result = {
            testId: this.currentTest.id,
            testTitle: this.currentTest.title,
            score: score,
            date: new Date().toISOString(),
            answers: this.userAnswers
        };
        
        // Save to history
        const history = JSON.parse(localStorage.getItem('test_history') || '[]');
        history.push(result);
        localStorage.setItem('test_history', JSON.stringify(history));
        
        // Clear progress
        this.clearProgress();
    }
    
    showTestResult(score) {
        // Create result modal
        const modal = document.createElement('div');
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
        `;
        
        const message = score >= 70 ? 
            `Congratulations! You passed the test with score: ${score}%` :
            `Test completed. Score: ${score}%. Keep practicing!`;
        
        modal.innerHTML = `
            <div style="
                background: white;
                padding: 3rem;
                border-radius: var(--radius-lg);
                text-align: center;
                max-width: 500px;
                animation: fadeIn 0.5s ease;
            ">
                <h2 style="margin-bottom: 1rem;">Test Completed!</h2>
                <div style="
                    font-size: 4rem;
                    font-weight: bold;
                    color: ${score >= 70 ? 'var(--success-color)' : 'var(--error-color)'};
                    margin: 2rem 0;
                ">
                    ${score}%
                </div>
                <p style="margin-bottom: 2rem; font-size: 1.25rem;">${message}</p>
                <p>Redirecting to certificate page...</p>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Add animation
        if (!document.getElementById('fadeInAnimation')) {
            const style = document.createElement('style');
            style.id = 'fadeInAnimation';
            style.textContent = `
                @keyframes fadeIn {
                    from { opacity: 0; transform: scale(0.9); }
                    to { opacity: 1; transform: scale(1); }
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    setupSearch() {
        const searchInput = document.getElementById('searchTests');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.filterTests(e.target.value);
            });
        }
    }
    
    setupFilters() {
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const filter = e.target.dataset.filter;
                this.applyFilter(filter);
                
                // Update active state
                filterButtons.forEach(btn => btn.classList.remove('active'));
                e.target.classList.add('active');
            });
        });
    }
    
    filterTests(searchTerm) {
        const cards = document.querySelectorAll('.test-card');
        searchTerm = searchTerm.toLowerCase();
        
        cards.forEach(card => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            const description = card.querySelector('.test-description').textContent.toLowerCase();
            const tags = Array.from(card.querySelectorAll('.tag'))
                .map(tag => tag.textContent.toLowerCase());
            
            const matches = title.includes(searchTerm) ||
                          description.includes(searchTerm) ||
                          tags.some(tag => tag.includes(searchTerm));
            
            card.style.display = matches ? 'block' : 'none';
        });
    }
    
    applyFilter(filter) {
        const cards = document.querySelectorAll('.test-card');
        
        cards.forEach(card => {
            const level = card.querySelector('.test-meta').textContent;
            
            switch(filter) {
                case 'all':
                    card.style.display = 'block';
                    break;
                case 'beginner':
                    card.style.display = level.includes('Beginner') ? 'block' : 'none';
                    break;
                case 'intermediate':
                    card.style.display = level.includes('Intermediate') ? 'block' : 'none';
                    break;
                case 'advanced':
                    card.style.display = level.includes('Advanced') ? 'block' : 'none';
                    break;
                case 'free':
                    const price = card.querySelector('.test-price').textContent;
                    card.style.display = price.includes('Free') ? 'block' : 'none';
                    break;
            }
        });
    }
    
    setupTestActions() {
        const startTestBtn = document.getElementById('startTestBtn');
        if (startTestBtn) {
            startTestBtn.addEventListener('click', () => {
                const testId = new URLSearchParams(window.location.search).get('id');
                this.startTest(testId);
            });
        }
    }
    
    setupTestControls() {
        const nextBtn = document.getElementById('nextQuestion');
        const prevBtn = document.getElementById('prevQuestion');
        const submitBtn = document.getElementById('submitTest');
        
        if (nextBtn) nextBtn.addEventListener('click', () => this.nextQuestion());
        if (prevBtn) prevBtn.addEventListener('click', () => this.previousQuestion());
        if (submitBtn) submitBtn.addEventListener('click', () => this.submitTest());
    }
    
    startTest(testId) {
        // Check if purchased or free
        const test = this.getMockTestDetails(testId);
        
        if (test.price.includes('Free')) {
            window.location.href = `begin-test.html?id=${testId}`;
        } else {
            // Redirect to payment page
            window.location.href = `payment.html?test=${testId}`;
        }
    }
    
    // Mock Data
    // Mock Data
getMockTests() {
    return [
        // Existing tests...
        {
            id: 'web-dev-basics',
            title: 'Web Development Basics',
            description: 'Test your knowledge of HTML, CSS, and JavaScript fundamentals',
            image: 'images/web-dev.jpg',
            tags: ['Frontend', 'Basics', 'HTML', 'CSS'],
            duration: 60,
            questions: 30,
            difficulty: 'Beginner',
            price: 'Free'
        },
        {
            id: 'react-advanced',
            title: 'Advanced React Concepts',
            description: 'Deep dive into React advanced features and best practices',
            image: 'images/react.jpg',
            tags: ['React', 'Frontend', 'Framework'],
            duration: 90,
            questions: 40,
            difficulty: 'Advanced',
            price: '$199'
        },
        {
            id: 'python-data-science',
            title: 'Python Data Analysis',
            description: 'Test your data processing and analysis skills with Python',
            image: 'images/python.jpg',
            tags: ['Python', 'Data Science', 'Pandas'],
            duration: 75,
            questions: 35,
            difficulty: 'Intermediate',
            price: '$149'
        },
        
        // NEW TESTS START HERE
        
        // Test 1: Java Programming
        {
            id: 'java-programming',
            title: 'Java Programming',
            description: 'Master Java fundamentals and object-oriented programming concepts',
            image: 'images/java.jpg',
            tags: ['Java', 'Programming', 'OOP', 'Backend'],
            duration: 60,
            questions: 30,
            difficulty: 'Intermediate',
            price: '₹14'
        },
        
        // Test 2: React.js Fundamentals
        {
            id: 'react-fundamentals',
            title: 'React.js Fundamentals',
            description: 'Learn React basics, components, state, and props',
            image: 'images/react-basic.jpg',
            tags: ['React', 'JavaScript', 'Frontend', 'UI'],
            duration: 45,
            questions: 25,
            difficulty: 'Beginner',
            price: '₹7'
        },
        
        // Test 3: SQL & Database
        {
            id: 'sql-database',
            title: 'SQL & Database Management',
            description: 'Test your SQL query skills and database design knowledge',
            image: 'images/sql.jpg',
            tags: ['SQL', 'Database', 'MySQL', 'PostgreSQL'],
            duration: 60,
            questions: 30,
            difficulty: 'Intermediate',
            price: '₹14'
        },
        
        // Test 4: Docker & Containers
        {
            id: 'docker-containers',
            title: 'Docker & Containerization',
            description: 'Validate your Docker, containers, and DevOps knowledge',
            image: 'images/docker.jpg',
            tags: ['Docker', 'DevOps', 'Containers', 'Deployment'],
            duration: 50,
            questions: 25,
            difficulty: 'Intermediate',
            price: '₹14'
        },
        
        // Test 5: Android Development
        {
            id: 'android-development',
            title: 'Android Development',
            description: 'Test your Android app development skills with Java/Kotlin',
            image: 'images/android.jpg',
            tags: ['Android', 'Mobile', 'Kotlin', 'App Development'],
            duration: 70,
            questions: 35,
            difficulty: 'Intermediate',
            price: '₹14'
        },
        
        // Test 6: UX/UI Design
        {
            id: 'ux-ui-design',
            title: 'UX/UI Design Principles',
            description: 'Validate your user experience and interface design skills',
            image: 'images/design.jpg',
            tags: ['Design', 'UI', 'UX', 'Figma'],
            duration: 45,
            questions: 20,
            difficulty: 'Beginner',
            price: '₹7'
        },
        
        // Test 7: Node.js Backend
        {
            id: 'nodejs-backend',
            title: 'Node.js Backend Development',
            description: 'Test your Node.js, Express, and backend API skills',
            image: 'images/nodejs.jpg',
            tags: ['Node.js', 'Backend', 'API', 'Express'],
            duration: 75,
            questions: 35,
            difficulty: 'Advanced',
            price: '₹19'
        },
        
        // Test 8: Machine Learning
        {
            id: 'machine-learning',
            title: 'Machine Learning Basics',
            description: 'Validate your ML concepts, algorithms, and Python implementation',
            image: 'images/ml.jpg',
            tags: ['ML', 'AI', 'Python', 'Data Science'],
            duration: 80,
            questions: 40,
            difficulty: 'Advanced',
            price: '₹19'
        },
        
        // Test 9: Cybersecurity
        {
            id: 'cybersecurity',
            title: 'Cybersecurity Fundamentals',
            description: 'Test your knowledge of security principles and threat prevention',
            image: 'images/security.jpg',
            tags: ['Security', 'Cybersecurity', 'Networking', 'Ethical Hacking'],
            duration: 65,
            questions: 30,
            difficulty: 'Intermediate',
            price: '₹14'
        },
        
        // Test 10: Cloud Computing (AWS)
        {
            id: 'aws-cloud',
            title: 'AWS Cloud Computing',
            description: 'Validate your Amazon Web Services cloud platform knowledge',
            image: 'images/aws.jpg',
            tags: ['AWS', 'Cloud', 'DevOps', 'Infrastructure'],
            duration: 90,
            questions: 45,
            difficulty: 'Advanced',
            price: '₹19'
        }
    ];
}

// Initialize TestManager
const testManager = new TestManager();

// Export to global scope
window.testManager = testManager;


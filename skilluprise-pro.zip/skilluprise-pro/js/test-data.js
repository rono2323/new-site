// js/test-data.js - Centralized Test Data
const TestData = {
    tests: [
        {
            id: 'python',
            name: 'Python Programming',
            category: 'programming',
            icon: 'fa-code',
            description: 'Validate your Python skills with industry-standard assessment',
            skills: ['Python Syntax', 'Data Structures', 'OOP', 'File Handling', 'Error Handling'],
            
            // Meta info for listing page
            meta: {
                rating: 4.8,
                taken: 8200,
                lastUpdated: 'Dec 2024'
            },
            
            // Pricing and levels
            levels: {
                beginner: {
                    price: 7,
                    questions: 10,
                    duration: 15,
                    certificate: 'Basic Certificate',
                    features: ['10 Questions', '15 Minutes', 'Basic Certificate']
                },
                intermediate: {
                    price: 14,
                    questions: 20,
                    duration: 30,
                    certificate: 'Professional Certificate',
                    features: ['20 Questions', '30 Minutes', 'Professional Certificate', 'Detailed Analytics']
                },
                pro: {
                    price: 19,
                    questions: 30,
                    duration: 45,
                    certificate: 'Premium Certificate',
                    features: ['30 Questions', '45 Minutes', 'Premium Certificate', 'Verification Portal', 'Digital Badge']
                }
            },
            
            // Questions for each level
            questions: {
                beginner: [
                    {
                        id: 1,
                        question: "What is the output of: print(3 * 'ab')?",
                        options: ["ababab", "3ab", "ab3", "Error"],
                        correct: 0,
                        explanation: "Multiplying a string repeats it."
                    },
                    
                    {
    id: 1,
    question: "What is the output of: print(3 * 'ab')?",
    options: ["ababab", "3ab", "ab3", "Error"],
    correct: 0,
    explanation: "Multiplying a string repeats it."
},
{
    id: 2,
    question: "Which of these is NOT a valid variable name?",
    options: ["my_var", "_variable", "2nd_var", "var2"],
    correct: 2,
    explanation: "Variable names cannot start with a number."
},
{
    id: 3,
    question: "What is the output of: print(type([]))?",
    options: ["<class 'list'>", "<class 'array'>", "<class 'tuple'>", "<class 'dict'>"],
    correct: 0,
    explanation: "Empty square brackets create a list."
},
{
    id: 4,
    question: "What does the len() function return for 'hello'?",
    options: ["4", "5", "6", "Error"],
    correct: 1,
    explanation: "len() counts the characters: h,e,l,l,o = 5 characters."
},
{
    id: 5,
    question: "What is the result of: 5 // 2?",
    options: ["2.5", "2", "3", "2.0"],
    correct: 1,
    explanation: "// performs floor division, returning the integer quotient."
},
{
    id: 6,
    question: "Which method adds an element to the end of a list?",
    options: [".push()", ".append()", ".insert()", ".add()"],
    correct: 1,
    explanation: "The .append() method adds an element to the end of a list."
},
{
    id: 7,
    question: "What is the output of: print(2 ** 3)?",
    options: ["6", "8", "9", "23"],
    correct: 1,
    explanation: "** is the exponent operator: 2 raised to power 3 = 8."
},
{
    id: 8,
    question: "Which keyword is used to define a function?",
    options: ["def", "function", "func", "define"],
    correct: 0,
    explanation: "Functions are defined using the 'def' keyword in Python."
},
{
    id: 9,
    question: "What is the result of: 'Hello' == 'hello'?",
    options: ["True", "False", "Error", "None"],
    correct: 1,
    explanation: "Python string comparison is case-sensitive."
}
                    // ... (all other beginner questions remain the same)
                ],
                intermediate: [
                    // ... (all intermediate questions remain the same)
                ],
                pro: [
                    // ... (all pro questions remain the same)
                ]
            },
            
            // Curriculum for each level
            curriculum: {
                beginner: [
                    "Basic Syntax and Variables",
                    "Data Types and Operators",
                    "Control Structures",
                    "Functions and Modules",
                    "Basic String Operations",
                    "List and Dictionary Basics",
                    "File I/O Introduction",
                    "Error Handling Basics",
                    "Basic Debugging",
                    "Python Best Practices"
                ],
                intermediate: [
                    // ... (intermediate curriculum items remain the same)
                ],
                pro: [
                    // ... (pro curriculum items remain the same)
                ]
            }
        },
        {
            id: 'javascript',
            name: 'JavaScript Fundamentals',
            category: 'programming',
            icon: 'fa-js',
            description: 'Master JavaScript fundamentals and modern ES6+ features',
            skills: ['ES6 Syntax', 'DOM Manipulation', 'Async Programming', 'Error Handling', 'Modern Features'],
            
            meta: {
                rating: 4.6,
                taken: 7800,
                lastUpdated: 'Dec 2024'
            },
            
            levels: {
                beginner: {
                    price: 7,
                    questions: 10,
                    duration: 15,
                    certificate: 'Basic Certificate',
                    features: ['10 Questions', '15 Minutes', 'Basic Certificate']
                },
                intermediate: {
                    price: 14,
                    questions: 20,
                    duration: 30,
                    certificate: 'Professional Certificate',
                    features: ['20 Questions', '30 Minutes', 'Professional Certificate', 'Detailed Analytics']
                },
                pro: {
                    price: 19,
                    questions: 30,
                    duration: 45,
                    certificate: 'Premium Certificate',
                    features: ['30 Questions', '45 Minutes', 'Premium Certificate', 'Verification Portal', 'Digital Badge']
                }
            },
            
            questions: {
                beginner: [
                    {
                        id: 1,
                        question: "Which company created JavaScript?",
                        options: ["Microsoft", "Netscape", "Google", "Apple"],
                        correct: 1,
                        explanation: "Netscape created JavaScript."
                    },
                    {
                        id: 2,
                        question: "How do you declare a variable in modern JavaScript?",
                        options: ["var", "let", "const", "Both let and const"],
                        correct: 3,
                        explanation: "let and const are modern declarations."
                    }
                ],
                intermediate: [
                    {
                        id: 1,
                        question: "What is a Promise in JavaScript?",
                        options: ["Synchronous operation", "Asynchronous operation handler", "Variable type", "Loop structure"],
                        correct: 1,
                        explanation: "Promise handles async operations."
                    }
                ],
                pro: [
                    {
                        id: 1,
                        question: "What is the event loop in JavaScript?",
                        options: ["A loop that runs events", "JavaScript's concurrency model", "Event handler", "DOM event system"],
                        correct: 1,
                        explanation: "Event loop is JavaScript's concurrency model."
                    }
                ]
            },
            
            curriculum: {
                beginner: [
                    "Variables and Data Types",
                    "Functions and Scope",
                    "DOM Manipulation",
                    "Events Handling",
                    "Basic ES6 Features"
                ],
                intermediate: [
                    "Advanced Functions",
                    "Promises and Async/Await",
                    "Modules and Imports",
                    "Error Handling",
                    "Modern ES6+ Features"
                ],
                pro: [
                    "Advanced Async Patterns",
                    "Memory Management",
                    "Performance Optimization",
                    "Design Patterns",
                    "Tooling and Build Systems"
                ]
            }
        }
        // You can add more test objects here
    ],
    
    // Get all tests for listing
    getAllTests: function() {
        return this.tests.map(test => {
            const levels = ['beginner', 'intermediate', 'pro'];
            return levels.map(level => ({
                id: test.id,
                name: test.name,
                category: test.category,
                level: level,
                price: test.levels[level].price,
                questions: test.levels[level].questions,
                duration: test.levels[level].duration,
                rating: test.meta.rating,
                taken: test.meta.taken
            }));
        }).flat();
    },
    
    // Get test by ID
    getTestById: function(id) {
        return this.tests.find(test => test.id === id);
    },
    
    // Get questions for specific test and level
    getQuestions: function(testId, level) {
        const test = this.getTestById(testId);
        return test ? test.questions[level] || [] : [];
    },
    
    // Get curriculum for specific test and level
    getCurriculum: function(testId, level) {
        const test = this.getTestById(testId);
        return test ? test.curriculum[level] || [] : [];
    },
    
    // Filter tests by category
    getTestsByCategory: function(category) {
        return this.tests.filter(test => test.category === category);
    },
    
    // Filter tests by level
    getTestsByLevel: function(level) {
        return this.getAllTests().filter(test => test.level === level);
    }
};
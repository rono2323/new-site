// Helper functions for formatting
function formatNumber(num) {
    if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'k';
    }
    return num.toString();
}

function createStars(rating) {
    return Array(5).fill(0).map((_, i) => {
        if (i < Math.floor(rating)) {
            return '<i class="fas fa-star"></i>';
        } else if (i < rating) {
            return '<i class="fas fa-star-half-alt"></i>';
        } else {
            return '<i class="far fa-star"></i>';
        }
    }).join('');
}
// Certificate Generation Functions

class CertificateManager {
    constructor() {
        this.certificateData = null;
        this.initializeCertificatePage();
    }
    
    initializeCertificatePage() {
        // Get certificate data from URL
        const urlParams = new URLSearchParams(window.location.search);
        const testId = urlParams.get('test');
        const score = urlParams.get('score');
        
        if (!testId || !score) {
            window.location.href = 'tests.html';
            return;
        }
        
        // Load certificate data
        this.loadCertificateData(testId, score);
        
        // Initialize download functionality
        this.initializeDownloadButtons();
        
        // Initialize sharing functionality
        this.initializeSharing();
        
        // Auto-generate certificate
        this.generateCertificate();
    }
    
    loadCertificateData(testId, score) {
        // Get user data
        const user = skilluprise.getUserData() || {
            name: 'John Doe',
            email: 'john@example.com'
        };
        
        // Get test data from history
        const history = JSON.parse(localStorage.getItem('test_history') || '[]');
        const testResult = history.find(item => item.testId === testId);
        
        // Create certificate data
        this.certificateData = {
            certificateId: 'CERT' + Date.now(),
            userName: user.name,
            userEmail: user.email,
            testId: testId,
            testTitle: testResult ? testResult.testTitle : 'Web Development Basics',
            score: parseInt(score),
            issueDate: new Date().toISOString(),
            expiryDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(), // 1 year from now
            certificateUrl: window.location.href
        };
        
        // Save certificate data
        this.saveCertificateRecord();
        
        // Update page with certificate data
        this.updateCertificateDisplay();
    }
    
    updateCertificateDisplay() {
        const elements = {
            userName: document.getElementById('userName'),
            testTitle: document.getElementById('testTitle'),
            score: document.getElementById('score'),
            certificateId: document.getElementById('certificateId'),
            issueDate: document.getElementById('issueDate'),
            expiryDate: document.getElementById('expiryDate')
        };
        
        // Format dates
        const formattedIssueDate = skilluprise.formatDate(this.certificateData.issueDate);
        const formattedExpiryDate = skilluprise.formatDate(this.certificateData.expiryDate);
        
        // Update elements
        if (elements.userName) elements.userName.textContent = this.certificateData.userName;
        if (elements.testTitle) elements.testTitle.textContent = this.certificateData.testTitle;
        if (elements.score) elements.score.textContent = `${this.certificateData.score}%`;
        if (elements.certificateId) elements.certificateId.textContent = this.certificateData.certificateId;
        if (elements.issueDate) elements.issueDate.textContent = formattedIssueDate;
        if (elements.expiryDate) elements.expiryDate.textContent = formattedExpiryDate;
        
        // Update status indicator
        this.updateStatusIndicator();
        
        // Update QR code
        this.generateQRCode();
    }
    
    updateStatusIndicator() {
        const statusElement = document.getElementById('certificateStatus');
        if (!statusElement) return;
        
        const isVerified = this.verifyCertificate();
        const isExpired = new Date(this.certificateData.expiryDate) < new Date();
        
        if (isExpired) {
            statusElement.textContent = 'Expired';
            statusElement.style.color = 'var(--error-color)';
        } else if (isVerified) {
            statusElement.textContent = 'Verified';
            statusElement.style.color = 'var(--success-color)';
        } else {
            statusElement.textContent = 'Pending Verification';
            statusElement.style.color = 'var(--accent-color)';
        }
    }
    
    verifyCertificate() {
        // Check if certificate exists in records
        const certificates = JSON.parse(localStorage.getItem('certificates') || '[]');
        const exists = certificates.some(cert => cert.certificateId === this.certificateData.certificateId);
        
        // Check if not expired
        const isExpired = new Date(this.certificateData.expiryDate) < new Date();
        
        return exists && !isExpired;
    }
    
    generateQRCode() {
        const qrContainer = document.getElementById('qrCode');
        if (!qrContainer) return;
        
        // Create QR code data URL
        const qrData = JSON.stringify({
            id: this.certificateData.certificateId,
            name: this.certificateData.userName,
            test: this.certificateData.testTitle,
            score: this.certificateData.score,
            date: this.certificateData.issueDate
        });
        
        // Create a simple QR code using canvas
        this.createSimpleQRCode(qrContainer, qrData);
    }
    
    createSimpleQRCode(container, data) {
        // Clear container
        container.innerHTML = '';
        
        // Create canvas for QR code
        const canvas = document.createElement('canvas');
        canvas.width = 200;
        canvas.height = 200;
        const ctx = canvas.getContext('2d');
        
        // Simple QR code pattern (for demo purposes)
        // In production, use a proper QR code library like qrcode.js
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, 200, 200);
        
        // Draw simple pattern
        ctx.fillStyle = 'black';
        
        // Draw border
        ctx.fillRect(10, 10, 180, 180);
        ctx.fillStyle = 'white';
        ctx.fillRect(20, 20, 160, 160);
        
        // Draw some squares (simulating QR code)
        ctx.fillStyle = 'black';
        for (let i = 0; i < 5; i++) {
            for (let j = 0; j < 5; j++) {
                if ((i + j) % 2 === 0) {
                    ctx.fillRect(40 + i * 25, 40 + j * 25, 15, 15);
                }
            }
        }
        
        // Add text
        ctx.fillStyle = 'black';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Scan to verify', 100, 190);
        
        container.appendChild(canvas);
        
        // Add click to verify
        canvas.style.cursor = 'pointer';
        canvas.addEventListener('click', () => {
            this.verifyCertificateOnline();
        });
    }
    
    async verifyCertificateOnline() {
        try {
            const response = await this.simulateVerification();
            
            if (response.verified) {
                skilluprise.showToast('Certificate verified successfully!', 'success');
            } else {
                skilluprise.showToast('Certificate verification failed', 'error');
            }
        } catch (error) {
            skilluprise.showToast('Verification service unavailable', 'warning');
        }
    }
    
    simulateVerification() {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    verified: this.verifyCertificate(),
                    certificateId: this.certificateData.certificateId,
                    timestamp: new Date().toISOString()
                });
            }, 1000);
        });
    }
    
    initializeDownloadButtons() {
        const pdfBtn = document.getElementById('downloadPDF');
        const pngBtn = document.getElementById('downloadPNG');
        
        if (pdfBtn) {
            pdfBtn.addEventListener('click', () => {
                this.downloadCertificate('pdf');
            });
        }
        
        if (pngBtn) {
            pngBtn.addEventListener('click', () => {
                this.downloadCertificate('png');
            });
        }
    }
    
    async downloadCertificate(format) {
        skilluprise.showToast(`Preparing ${format.toUpperCase()} download...`, 'info');
        
        // Get certificate element
        const certificateElement = document.getElementById('certificatePreview');
        if (!certificateElement) return;
        
        try {
            switch(format) {
                case 'pdf':
                    await this.generatePDF(certificateElement);
                    break;
                case 'png':
                    await this.generatePNG(certificateElement);
                    break;
            }
            
            skilluprise.showToast('Download started!', 'success');
        } catch (error) {
            skilluprise.showToast(`Download failed: ${error.message}`, 'error');
        }
    }
    
    async generatePDF(element) {
        // In production, use a library like jsPDF with html2canvas
        // For now, simulate PDF generation
        
        const { jsPDF } = window.jspdf;
        if (!jsPDF) {
            throw new Error('PDF generation library not available');
        }
        
        // Create PDF
        const pdf = new jsPDF('l', 'mm', 'a4');
        
        // Add certificate content
        pdf.setFontSize(24);
        pdf.text('Certificate of Achievement', 105, 30, { align: 'center' });
        
        pdf.setFontSize(16);
        pdf.text('This certifies that', 105, 50, { align: 'center' });
        
        pdf.setFontSize(20);
        pdf.text(this.certificateData.userName, 105, 65, { align: 'center' });
        
        pdf.setFontSize(16);
        pdf.text(`has successfully completed the ${this.certificateData.testTitle} test`, 105, 80, { align: 'center' });
        
        pdf.setFontSize(18);
        pdf.text(`with a score of ${this.certificateData.score}%`, 105, 95, { align: 'center' });
        
        // Add dates
        pdf.setFontSize(12);
        pdf.text(`Issued: ${skilluprise.formatDate(this.certificateData.issueDate)}`, 20, 150);
        pdf.text(`Expires: ${skilluprise.formatDate(this.certificateData.expiryDate)}`, 20, 160);
        
        // Add certificate ID
        pdf.text(`Certificate ID: ${this.certificateData.certificateId}`, 190, 150, { align: 'right' });
        
        // Save PDF
        pdf.save(`certificate_${this.certificateData.certificateId}.pdf`);
    }
    
    async generatePNG(element) {
        // Use html2canvas to capture certificate as image
        const html2canvas = window.html2canvas;
        if (!html2canvas) {
            throw new Error('Image capture library not available');
        }
        
        const canvas = await html2canvas(element, {
            scale: 2,
            backgroundColor: '#ffffff',
            useCORS: true
        });
        
        // Convert to data URL and trigger download
        const link = document.createElement('a');
        link.download = `certificate_${this.certificateData.certificateId}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
    }
    
    initializeSharing() {
        const shareButtons = document.querySelectorAll('.share-btn');
        shareButtons.forEach(button => {
            button.addEventListener('click', () => {
                const platform = button.dataset.platform;
                this.shareCertificate(platform);
            });
        });
    }
    
    shareCertificate(platform) {
        const shareUrl = window.location.href;
        const shareText = `I just earned a certificate in ${this.certificateData.testTitle} with ${this.certificateData.score}% score on SkillUprise Pro!`;
        
        let shareLink = '';
        
        switch(platform) {
            case 'linkedin':
                shareLink = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
                break;
            case 'twitter':
                shareLink = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
                break;
            case 'facebook':
                shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
                break;
            case 'whatsapp':
                shareLink = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
                break;
            case 'email':
                shareLink = `mailto:?subject=My%20Certificate%20Achievement&body=${encodeURIComponent(shareText + '\n\nView certificate: ' + shareUrl)}`;
                break;
        }
        
        if (shareLink) {
            window.open(shareLink, '_blank', 'noopener,noreferrer');
        }
    }
    
    generateCertificate() {
        // Add certificate design elements
        this.addCertificateDesign();
        
        // Add signature if available
        this.addSignature();
        
        // Add seal/stamp
        this.addSeal();
    }
    
    addCertificateDesign() {
        const certificate = document.getElementById('certificatePreview');
        if (!certificate) return;
        
        // Add decorative border
        certificate.style.border = '20px solid transparent';
        certificate.style.borderImage = 'linear-gradient(45deg, #667eea, #764ba2) 30';
        
        // Add background pattern
        certificate.style.backgroundImage = `
            radial-gradient(circle at 25% 25%, rgba(102, 126, 234, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 75% 75%, rgba(118, 75, 162, 0.1) 0%, transparent 50%)
        `;
        certificate.style.backgroundSize = '100% 100%';
    }
    
    addSignature() {
        const signatureContainer = document.getElementById('signatureContainer');
        if (!signatureContainer) return;
        
        signatureContainer.innerHTML = `
            <div style="text-align: center; margin-top: 3rem;">
                <div style="
                    border-top: 2px solid #333;
                    width: 200px;
                    margin: 0 auto 0.5rem;
                    padding-top: 0.5rem;
                ">
                    <div style="font-weight: bold;">Dr. Alex Johnson</div>
                    <div style="color: #666; font-size: 0.875rem;">Chief Learning Officer</div>
                    <div style="color: #666; font-size: 0.875rem;">SkillUprise Pro</div>
                </div>
            </div>
        `;
    }
    
    addSeal() {
        const sealContainer = document.getElementById('sealContainer');
        if (!sealContainer) return;
        
        const canvas = document.createElement('canvas');
        canvas.width = 120;
        canvas.height = 120;
        const ctx = canvas.getContext('2d');
        
        // Draw circular seal
        ctx.beginPath();
        ctx.arc(60, 60, 55, 0, Math.PI * 2);
        ctx.strokeStyle = '#d4af37';
        ctx.lineWidth = 3;
        ctx.stroke();
        
        // Add text around circle
        ctx.font = 'bold 14px Arial';
        ctx.fillStyle = '#d4af37';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Draw text around circle (simplified)
        ctx.fillText('OFFICIAL', 60, 40);
        ctx.fillText('SEAL', 60, 60);
        ctx.fillText('SKILLUPRISE', 60, 80);
        
        sealContainer.appendChild(canvas);
    }
    
    saveCertificateRecord() {
        // Save to certificate records
        const certificates = JSON.parse(localStorage.getItem('certificates') || '[]');
        certificates.push(this.certificateData);
        localStorage.setItem('certificates', JSON.stringify(certificates));
        
        // Update user profile with certificate
        const user = skilluprise.getUserData();
        if (user) {
            if (!user.certificates) {
                user.certificates = [];
            }
            user.certificates.push(this.certificateData.certificateId);
            skilluprise.saveUserData(user);
        }
    }
}

// Initialize CertificateManager when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.certificateManager = new CertificateManager();
});